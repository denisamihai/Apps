---
name: edition-pdf-generator
description: Generate the printable two-page edition of The AI Horizons Times as a PDF, with the Doom Forecast gauge and a QR code for every story. Use this skill at the end of the morning edition, once all four child agents have returned their sections and the edition JSON is assembled. The skill runs a bundled Python script that renders the confirmed edition content onto the fixed newspaper template as a real PDF file.
---

# The AI Horizons Times Edition PDF Generator

This skill produces the printable edition that closes out the morning run. You collect the final edition JSON that the child agents have already produced, and then you run the bundled `edition_pdf.py` script to render it to a PDF using reportlab. You do not draw the PDF yourself, write your own rendering code, or change any headline, figure, or link. Every value comes from earlier steps: the Work IQ Agent, the News Desk Agent, the Bright Side Agent, and the Doomometer Agent with its compute script.

## When to use

Use this skill last, after every section is final:

- the Work IQ Agent has returned the reader's priorities, or a section marked "unavailable";
- the News Desk Agent has returned the lead story and the six section stories;
- the Bright Side Agent has returned its items;
- the Doomometer Agent has returned the forecast, including the median from its compute script;
- the edition JSON has passed the orchestrator's validation.

This skill never decides, selects, or rewrites anything. It only renders the edition the agents produced.

## What goes where on the page

The layout reproduces the reference design "Newspaper_feed_with_QR_codes.pdf" on two US Letter pages. Every placeholder slot receives the matching edition content.

| Template slot | Edition content |
|---|---|
| Masthead | `edition.date` and `edition.edition_number` |
| Page one, lead story with QR code | `news.lead` |
| Page one, lead-image box | The Doom Forecast gauge, median, range, statement count, trend, and IMD clock reading from `doom` |
| Page one, six cards | `news.stories`: Business, Policy, Startups, Events, World, Public Sector |
| Page one, opinion row | The forecast caption and the stated estimates from `doom`, plus the fixed reliability sentence |
| Page one, teaser strip | Fixed session teaser text |
| Page two, feature with QR code | "Your Day": the counts headline and `workiq.burning`, with a QR code for the top item |
| Page two, feature-image box | "Be ready for": `workiq.be_ready_for`, with a QR code per item |
| Page two, four cards | The three `bright_side.items`, and "On your desk" with `workiq.important`, `workiq.waiting`, and `workiq.can_wait_count` |

## Section statuses and validation

The script reads the `status` field of each section:

- **ok** prints the section normally.
- **unavailable** prints the fixed notice "This section did not file today."
- **insufficient** (Doomometer only) draws the gauge without a needle and prints "No reading today", together with the clock reading.

Before drawing, the script validates the edition:

- A missing or malformed `edition.date` stops the script with an `Error:` line, and no PDF is written.
- Stories without a valid section or a headline, and a second story in the same section, are left out.
- Bright Side items without one of the allowed domains, and a second item in the same domain, are left out.
- Doom statements without a named speaker or without a figure are left out. Collective labels such as "consensus" or "experts" do not count as speakers.
- The gauge shows a reading only when at least three named statements with figures remain.

Every item that is left out is reported as a line starting with `NOTE:`. The reliability sentence in the opinion row is fixed template text, so the doom section does not need to supply it.

## Workflow

### 1. Assemble the edition

Use the edition JSON exactly as validated by the orchestrator. Keep dates in the format YYYY-MM-DD and percentages as numbers, because the script formats them. Omit optional fields that are empty; the script leaves out their lines and QR codes.

| Field | Meaning |
|---|---|
| `edition` | The date, the city, and the edition number when one is available |
| `workiq` | The status, focus topics, Burning, Important, Waiting, the Can wait count, and Be ready for |
| `news` | The status, the lead story, and the six section stories |
| `bright_side` | The status and up to three items |
| `doom` | The status, median, range, count, trend, clock reading, caption, reliability note, and statements |

### 2. Run the bundled script

Write the JSON to a file and pass it to `edition_pdf.py`. The edition is too long for a command-line string.

```
python3 edition_pdf.py --edition-file edition.json --output ai_horizons_times_2026-09-22.pdf
```

Name the output file `ai_horizons_times_<date>.pdf`, using the edition date. Add these options only when they apply:

- `--edition-number N` prints the edition number when the JSON has none.
- `--mono` draws the gauge in greys, which is needed when the printer has no colour.
- `--thresholds LOW HIGH` changes the gauge bands. The default is green up to 5 percent, yellow up to 20 percent, and red above that. The script prints the bands under the gauge.

A complete sample is in `assets/sample-edition.json`, with its rendered result in `assets/sample-edition.pdf`. Use them for a dry run:

```
python3 edition_pdf.py --edition-file assets/sample-edition.json --output sample.pdf
```

The script writes the PDF and prints `WROTE <filename>`, preceded by any `NOTE:` lines. When it prints a line starting with `Error:`, report that line and stop, because an invalid edition must not go to the printer.

### 3. Report

- Confirm that the PDF was written, using the file name from the `WROTE` line.
- Pass every `NOTE:` line on to the orchestrator, because each one names an item that is missing from the printed edition.
- Pass the file to the next step of the orchestrator, which sends it to the printer.

## Notes

- The script uses reportlab for the layout, the gauge, and the QR codes. It makes no network calls.
- The layout is fixed to two US Letter pages, matching the reference design. When printing on A4, use the printer's "fit to page" setting.
- Long text shrinks slightly and is then shortened with an ellipsis so that it fits its box. Lists drop whole items from the end and print a note that further items did not fit.
- Pass plain text in the values. The script escapes the characters that reportlab treats as markup.
- The fonts are bundled in `assets/fonts` under the SIL Open Font License: Gelasio (metric-compatible with Georgia), Archivo Black (in place of Arial Black), and Inconsolata (in place of Consolas). They cover Czech and Romanian characters. The script needs the `assets/fonts` folder next to it.
