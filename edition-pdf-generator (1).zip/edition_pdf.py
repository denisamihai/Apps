#!/usr/bin/env python3
"""The AI Horizons Times -> PDF renderer.

Renders the two-page daily edition of The AI Horizons Times on the fixed
newspaper template (US Letter). Every box, rule, font size, and colour is taken
from the reference design "Newspaper_feed_with_QR_codes.pdf". All content is
passed in as one JSON document assembled by the Editor-in-Chief from the four
child agents; this script only lays the content out, draws the Doom Forecast
gauge and the QR codes, and writes the PDF.

Usage:
    python3 edition_pdf.py --edition-file edition.json [--output ai_horizons_times.pdf]
    python3 edition_pdf.py --edition-json '<json>' [--output ai_horizons_times.pdf]

Options:
    --edition-number N     Printed as "No. N" in the masthead when the JSON has none.
    --thresholds LOW HIGH  Upper limits of the green and yellow gauge bands (default 5 20).
    --mono                 Draw the gauge in greys for black-and-white printers.

Slot mapping
    Page one:  lead story (news.lead) with QR; the lead-image box holds the
               Doom Forecast gauge (doom); six cards (news.stories); the opinion
               row holds the forecast caption, the stated estimates, and the
               reliability note (doom); fixed session teaser strip.
    Page two:  the feature holds "Your Day" (workiq.burning) with a QR code for
               the top item; the feature-image box holds "Be ready for"
               (workiq.be_ready_for); the four cards hold the three Bright Side
               items (bright_side.items) and "On your desk" (workiq.important,
               workiq.waiting, workiq.can_wait_count).

Every value comes from earlier steps. This script never writes, changes, or
invents content. Sections whose status is not "ok" print a fixed notice.

Validation: a missing or malformed edition date stops the script with an Error
line, so nothing is printed. Items that break the contract are left out and
reported as NOTE lines: stories without a valid section or headline, Bright Side
items without a valid or with a repeated domain, and doom statements without a
named speaker or a figure. The doom gauge shows a reading only when at least
three named statements with figures remain; otherwise it is drawn in colour
without a needle. The reliability sentence is fixed template text.

Fonts are bundled in assets/fonts under the SIL Open Font License: Gelasio
(metric-compatible with Georgia), Archivo Black (in place of Arial Black), and
Inconsolata (in place of Consolas). The only dependency is reportlab, and no
network calls are made.
"""

import argparse
import json
import math
import os
import sys
from datetime import datetime

# ---------------------------------------------------------------- template --
PAGE_W, PAGE_H = 612.0, 792.0
LEFT, RIGHT = 39.7, 572.2
WIDTH = RIGHT - LEFT

INK = "#252D31"
MUTED = "#6E6F86"
ACCENT = "#6B3FE8"

TITLE = "THE AI HORIZONS TIMES"
EDITION_NAME = "Prague Edition"
TAGLINE = "Beyond the AI Hype — a daily dispatch on artificial intelligence, business & policy"
EVENT = "CUBEX, PRAGUE · SEP 23–24"
TEASER_LABEL = "FROM WORK IQ & COPILOT STUDIO"
TEASER_TEXT = "Your Agent Now Has Email Access. It Liked the One From Your Manager — "
TEASER_BY = "by Denisa Mihai and Ana Inés Urrutia"
FOOTER = "THE AI HORIZONS TIMES · PRINTED FOR ONE READER"
BYLINE = "BY THE EDITOR"
SECTIONS = ["BUSINESS", "POLICY", "STARTUPS", "EVENTS", "WORLD", "PUBLIC SECTOR"]
NOTICE = "This section did not file today."
NOTICE_DOOM = "Too few named estimates were found today, so there is no reading."
RELIABILITY = ("These figures are personal estimates with differing definitions and time horizons, "
               "and they are opinions rather than measurements.")
GENERIC_SPEAKERS = {
    "", "consensus", "expert consensus", "experts", "expert", "researchers", "independent researchers",
    "academics", "scientists", "analysts", "observers", "insiders", "industry", "unknown",
    "anonymous", "various", "others", "n/a", "none", "multiple", "surveys", "polls",
}
MIN_STATEMENTS = 3
BRIGHT_DOMAINS = {"health", "climate", "climate and environment", "environment", "science",
                  "accessibility", "education", "public services", "agriculture", "safety"}

GAUGE = {
    "color": {"red": ("#D9453B", "#B9362D"), "yellow": ("#F2CF3A", "#D6B22A"),
              "green": ("#5BAE4F", "#47973D"), "needle": INK},
    "mono": {"red": ("#4A4A4A", "#3A3A3A"), "yellow": ("#9A9A9A", "#858585"),
             "green": ("#D2D2D2", "#BDBDBD"), "needle": "#111111"},
    "empty": {"red": ("#E4E4E7", "#D6D6DB"), "yellow": ("#ECECEF", "#DFDFE4"),
              "green": ("#E4E4E7", "#D6D6DB"), "needle": INK},
}

FONT_FILES = {
    "Serif": "Gelasio-Regular.ttf",
    "Serif-Bold": "Gelasio-Bold.ttf",
    "Serif-Italic": "Gelasio-Italic.ttf",
    "Serif-BoldItalic": "Gelasio-BoldItalic.ttf",
    "Head": "ArchivoBlack-Regular.ttf",
    "Mono": "Inconsolata-Regular.ttf",
    "Mono-Bold": "Inconsolata-Bold.ttf",
}


def _esc(text):
    return str(text or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _ok(section):
    return isinstance(section, dict) and section.get("status", "ok") == "ok"


def _pct(value):
    return f"{float(value):g}%"


def _dates(value):
    """Return (masthead date, long byline date, short byline date)."""
    try:
        d = datetime.strptime(str(value), "%Y-%m-%d")
    except (TypeError, ValueError):
        v = str(value or "")
        return v, v.upper(), v.upper()
    return (f"{d:%b}. {d.day}, {d.year}", f"{d:%b} {d.day}, {d.year}".upper(),
            f"{d:%b} {d.day}".upper())


def register_fonts():
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.lib.fonts import addMapping

    folder = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "fonts")
    for name, filename in FONT_FILES.items():
        pdfmetrics.registerFont(TTFont(name, os.path.join(folder, filename)))
    for family, normal, bold, italic, bold_italic in (
            ("Serif", "Serif", "Serif-Bold", "Serif-Italic", "Serif-BoldItalic"),
            ("Mono", "Mono", "Mono-Bold", "Mono", "Mono-Bold"),
            ("Head", "Head", "Head", "Head", "Head")):
        addMapping(family, 0, 0, normal)
        addMapping(family, 1, 0, bold)
        addMapping(family, 0, 1, italic)
        addMapping(family, 1, 1, bold_italic)


class Page:
    """Drawing helpers that take positions measured from the top of the page."""

    def __init__(self, canvas, thresholds, palette):
        from reportlab.lib import colors
        from reportlab.lib.styles import ParagraphStyle
        from reportlab.pdfbase.pdfmetrics import stringWidth

        self.c = canvas
        self.colors = colors
        self.PS = ParagraphStyle
        self.sw = stringWidth
        self.thresholds = thresholds
        self.palette = palette

        def st(name, font, size, leading, color=INK):
            return ParagraphStyle(name, fontName=font, fontSize=size, leading=leading,
                                  textColor=colors.HexColor(color))

        self.s = {
            "lead_head": st("lead_head", "Head", 21, 22.8),
            "lead_dek": st("lead_dek", "Serif", 9.7, 14.8),
            "card_head": st("card_head", "Head", 10.5, 12),
            "card_dek": st("card_dek", "Serif", 7.9, 11.2),
            "feat_head": st("feat_head", "Head", 18, 20.2),
            "feat_body": st("feat_body", "Serif", 9.4, 14),
            "card2_head": st("card2_head", "Head", 11.2, 12.8),
            "card2_dek": st("card2_dek", "Serif", 8.2, 11.6),
            "op_head": st("op_head", "Serif-BoldItalic", 11.2, 13.6),
            "op_dek": st("op_dek", "Serif", 7.9, 10.5),
            "note": st("note", "Serif-Italic", 7.6, 10.2, MUTED),
            "panel_head": st("panel_head", "Serif-Bold", 11, 13),
            "panel_body": st("panel_body", "Serif", 8, 10.6),
        }

    # -- primitives
    def y(self, top):
        return PAGE_H - top

    def fill(self, color):
        self.c.setFillColor(self.colors.HexColor(color))

    def bar(self, x, top, w, h, color=INK):
        self.fill(color)
        self.c.rect(x, self.y(top + h), w, h, stroke=0, fill=1)

    def frame(self, x, top, w, h):
        self.c.setStrokeColor(self.colors.HexColor(INK))
        self.c.setLineWidth(0.7)
        self.c.rect(x, self.y(top + h), w, h, stroke=1, fill=0)

    def text(self, x, base, s, font, size, color=INK, align="left", space=0.0):
        self.fill(color)
        self.c.setFont(font, size)
        width = self.sw(s, font, size) + space * max(len(s) - 1, 0)
        if align == "right":
            x -= width
        elif align == "center":
            x -= width / 2
        self.c.drawString(x, self.y(base), s, charSpace=space)
        return width

    def label(self, x, base, s, size=6.0):
        return self.text(x, base, s, "Mono-Bold", size, ACCENT, space=0.65)

    def tag(self, x, top, s):
        width = self.sw(s, "Mono-Bold", 6.7) + 0.7 * (len(s) - 1)
        self.bar(x, top, width + 11.0, 10.5, ACCENT)
        self.text(x + 5.1, top + 7.5, s, "Mono-Bold", 6.7, "#FFFFFF", space=0.7)

    def para(self, text, key, width, max_h=10000.0, markup=False, min_size=None):
        from reportlab.platypus import Paragraph

        base = self.s[key]
        min_size = min_size or max(base.fontSize - 2.5, 5.5)
        size = base.fontSize
        body = text if markup else _esc(text)
        while True:
            style = self.PS(f"{base.name}{size}", parent=base, fontSize=size,
                            leading=size * base.leading / base.fontSize)
            p = Paragraph(body, style)
            _, h = p.wrap(width, max_h)
            if h <= max_h or size <= min_size:
                break
            size -= 0.25
        if h > max_h and not markup:
            words = str(text).split()
            while words and h > max_h:
                words.pop()
                p = Paragraph(_esc(" ".join(words)) + "…", style)
                _, h = p.wrap(width, max_h)
        return p, h

    def put(self, p, h, x, top):
        p.drawOn(self.c, x, self.y(top + h))
        return h

    def write(self, text, key, x, top, width, max_h=10000.0, markup=False, min_size=None):
        p, h = self.para(text, key, width, max_h, markup, min_size)
        return self.put(p, h, x, top)

    def write_rows(self, rows, key, x, top, width, max_h, min_size=6.5,
                   overflow="<i>Further items did not fit and remain in your inbox.</i>"):
        """Write list rows, dropping whole rows from the end when they do not fit."""
        for k in range(len(rows), 0, -1):
            body = "<br/>".join(rows[:k] + ([overflow] if k < len(rows) else []))
            p, h = self.para(body, key, width, max_h, markup=True, min_size=min_size)
            if h <= max_h:
                return self.put(p, h, x, top)
        p, h = self.para(overflow, key, width, max_h, markup=True, min_size=min_size)
        return self.put(p, h, x, top)

    def qr(self, url, x, top, size):
        if not url:
            return False
        from reportlab.graphics.barcode.qr import QrCodeWidget
        from reportlab.graphics.shapes import Drawing
        from reportlab.graphics import renderPDF

        widget = QrCodeWidget(str(url))
        widget.barBorder = 0
        widget.barFillColor = self.colors.HexColor(INK)
        x1, y1, x2, y2 = widget.getBounds()
        drawing = Drawing(size, size, transform=[size / (x2 - x1), 0, 0, size / (y2 - y1), 0, 0])
        drawing.add(widget)
        renderPDF.draw(drawing, self.c, x, self.y(top + size))
        return True

    def footer(self, page_label):
        self.bar(LEFT, 754.5, WIDTH, 0.7)
        self.text(39.6, 765.0, FOOTER, "Mono", 5.6, MUTED)
        self.text(572.4, 765.0, page_label, "Mono", 5.6, MUTED, align="right")

    # -- gauge
    def angle(self, value):
        low, high = self.thresholds
        v = max(0.0, min(float(value), 100.0))
        if v <= low:
            return 60.0 * v / low
        if v <= high:
            return 60.0 + 60.0 * (v - low) / (high - low)
        return 120.0 + 60.0 * (v - high) / (100.0 - high)

    def gauge(self, cx, cy_top, radius, median, palette=None):
        c, col = self.c, self.colors
        pal = GAUGE[palette or self.palette]
        cy = self.y(cy_top)
        inner, shade = radius * 0.42, radius * 0.09
        bands = [("red", 120), ("yellow", 60), ("green", 0)]
        for layer, r in ((0, radius), (1, inner + shade)):
            for name, start in bands:
                c.setFillColor(col.HexColor(pal[name][layer]))
                c.wedge(cx - r, cy - r, cx + r, cy + r, start, 60, stroke=0, fill=1)
        c.setFillColor(col.white)
        c.wedge(cx - inner, cy - inner, cx + inner, cy + inner, 0, 180, stroke=0, fill=1)
        if median is None:
            return
        a = math.radians(self.angle(median))
        length, base = radius * 0.7, radius * 0.07
        pts = [(cx + length * math.cos(a), cy + length * math.sin(a)),
               (cx + base * math.cos(a + math.pi / 2), cy + base * math.sin(a + math.pi / 2)),
               (cx + base * math.cos(a - math.pi / 2), cy + base * math.sin(a - math.pi / 2))]
        path = c.beginPath()
        path.moveTo(*pts[0])
        path.lineTo(*pts[1])
        path.lineTo(*pts[2])
        path.close()
        c.setFillColor(col.HexColor(pal["needle"]))
        c.drawPath(path, stroke=0, fill=1)
        c.circle(cx, cy, radius * 0.11, stroke=0, fill=1)
        c.setFillColor(col.white)
        c.circle(cx, cy, radius * 0.045, stroke=0, fill=1)


# ---------------------------------------------------------------- page one --
def page_one(pg, ed):
    meta = ed.get("edition") or {}
    mast_date, long_date, short_date = _dates(meta.get("date"))
    number = meta.get("edition_number")

    # Masthead.
    pg.bar(LEFT, 28.5, WIDTH, 0.7)
    pg.text(569.0, 51.7, EDITION_NAME, "Serif-Italic", 8.2, align="right")
    pg.text(PAGE_W / 2, 58.5, TITLE, "Serif-Bold", 25.5, align="center")
    vol = "Vol. I" + (f" ... No. {int(number):02d}" if number else "")
    pg.text(42.6, 60.7, vol, "Serif-Italic", 8.2)
    pg.text(569.0, 60.7, mast_date, "Serif-Italic", 8.2, align="right")
    pg.bar(LEFT, 68.2, WIDTH, 2.2)
    pg.bar(LEFT, 71.2, WIDTH, 0.7)
    pg.bar(LEFT, 73.5, WIDTH, 1.5, ACCENT)
    pg.text(41.1, 93.7, TAGLINE, "Serif-Italic", 9.0)
    pg.text(570.9, 93.7, EVENT, "Mono", 6.7, MUTED, align="right")
    pg.bar(LEFT, 103.5, WIDTH, 0.7)

    # Lead story.
    news = ed.get("news") or {}
    pg.tag(LEFT, 111.7, "AI & TECH")
    lead = news.get("lead") if _ok(news) else None
    col_w = 296.0
    if lead:
        top = 129.5
        top += pg.write(lead.get("headline", ""), "lead_head", 39.6, top, col_w, max_h=92, min_size=15)
        pg.text(39.6, top + 8.0, f"{BYLINE} · {long_date}", "Mono", 6.7, MUTED)
        top += 14.5
        top += pg.write(lead.get("dek", ""), "lead_dek", 39.6, top, col_w,
                        max_h=max(284.0 - top, 15), min_size=7.5)
        if lead.get("relevance_note"):
            p, h = pg.para(lead["relevance_note"], "note", col_w, 10000)
            if h <= 284.0 - top - 2:
                pg.put(p, h, 39.6, top + 2)
        if pg.qr(lead.get("url"), 39.7, 290.2, 43.5):
            pg.text(90.6, 310.5, "SCAN FOR", "Mono", 6.7)
            pg.text(90.6, 318.0, "FULL STORY →", "Mono", 6.7)
    else:
        pg.write(NOTICE, "note", 39.6, 132.0, col_w)

    # Doom Forecast panel in the lead-image box.
    doom_panel(pg, ed.get("doom") or {})
    pg.bar(LEFT, 342.7, WIDTH, 0.7)

    # Six cards.
    stories = {s.get("section", "").upper(): s for s in news.get("stories") or []} if _ok(news) else {}
    cols = [(39.6, 166.6, 39.7), (227.7, 155.5, 228.0), (405.3, 166.9, 405.0)]
    for i, section in enumerate(SECTIONS):
        tx, tw, qx = cols[i % 3]
        dy = 154.5 * (i // 3)
        news_card(pg, stories.get(section), section, tx, tw, qx, dy, short_date)
    for x in (216.7, 393.7):
        pg.bar(x, 352.5, 0.7, 293.2)
    pg.bar(LEFT, 498.7, WIDTH, 0.7)
    pg.bar(LEFT, 645.7, WIDTH, 0.7)

    opinion_row(pg, ed.get("doom") or {})

    # Session teaser strip.
    pg.bar(LEFT, 733.5, WIDTH, 0.7)
    pg.label(39.6, 746.2, TEASER_LABEL)
    w = pg.text(163.0, 746.2, TEASER_TEXT, "Serif", 7.9)
    pg.text(163.0 + w, 746.2, TEASER_BY, "Mono", 6.4)
    pg.footer("PAGE 01")


def news_card(pg, story, section, tx, tw, qx, dy, short_date):
    pg.label(tx, 357.7 + dy, section)
    if not story:
        pg.write(NOTICE, "note", tx, 363.0 + dy, tw)
        return
    top = 363.2 + dy
    top += pg.write(story.get("headline", ""), "card_head", tx, top, tw, max_h=37, min_size=8.5)
    pg.text(tx, top + 6.5, f"{BYLINE} · {short_date}", "Mono", 5.6, MUTED)
    top += 11.0
    bottom = 461.0 + dy
    top += pg.write(story.get("dek", ""), "card_dek", tx, top, tw,
                    max_h=max(bottom - top, 11), min_size=6.8)
    note = story.get("relevance_note")
    if note:
        p, h = pg.para(note, "note", tw, 10000, min_size=6.5)
        if h <= bottom - top - 2:
            pg.put(p, h, tx, top + 2)
    if pg.qr(story.get("url"), qx, 467.2 + dy, 24.0):
        pg.text(qx + 28.4, 480.7 + dy, "SCAN FOR MORE", "Mono", 5.2)


def doom_panel(pg, doom):
    x, top, w, h = 346.5, 111.7, 225.7, 222.0
    pg.frame(x, top, w, h)
    cx = x + w / 2
    pg.label(x + 10, 124.5, "DOOMOMETER", 6.7)
    pg.text(x + 10, 140.0, "The Doom Forecast", "Serif-Bold", 12.5)
    ok = doom.get("_valid", False)
    if ok:
        pg.gauge(cx, 232.0, 70.0, doom["median_pct"])
        pg.text(cx, 262.0, _pct(doom["median_pct"]), "Head", 20, align="center")
        parts = []
        if doom.get("low_pct") is not None and doom.get("high_pct") is not None:
            parts.append(f"RANGE {_pct(doom['low_pct'])}–{_pct(doom['high_pct'])}")
        parts.append(f"{int(doom.get('n') or 0)} STATEMENTS")
        if doom.get("trend") and doom["trend"] != "none":
            parts.append(f"TREND {str(doom['trend']).upper()}")
        pg.text(cx, 276.0, " · ".join(parts), "Mono", 6.2, align="center")
    else:
        pg.gauge(cx, 232.0, 70.0, None)
        pg.text(cx, 260.0, "NO READING TODAY", "Head", 12, MUTED, align="center")
        pg.write(NOTICE_DOOM, "note", x + 25, 266.0, w - 50)
    if doom.get("clock_reading"):
        clock = f"IMD AI SAFETY CLOCK: {str(doom['clock_reading']).upper()}"
        size = 6.2
        while size > 4.5 and pg.sw(clock, "Mono", size) > w - 20:
            size -= 0.2
        pg.text(cx, 290.0, clock, "Mono", size, align="center")
    low, high = pg.thresholds
    pg.text(cx, 302.0, f"Bands: green up to {low:g}%, yellow up to {high:g}%, red above {high:g}%.",
            "Serif-Italic", 6.5, MUTED, align="center")
    pg.text(cx, 322.0, "Opinion, measured. The estimates are below.", "Serif-Italic", 7, MUTED,
            align="center")


def opinion_row(pg, doom):
    head_x, head_w = 78.4, 355.0
    statements = doom.get("statements") or []
    caption = (doom.get("caption") or "") if doom.get("_valid") else ""
    parts = []
    for st in statements[:5]:
        piece = f"<b>{_esc(st.get('person'))}</b> {_esc(st.get('pct_text'))}"
        if st.get("definition"):
            piece += f" ({_esc(st.get('definition'))})"
        parts.append(piece)
    hp, hh = pg.para(caption, "op_head", head_w, 28, min_size=9) if caption else (None, 0)
    sp, sh = pg.para(" · ".join(parts), "op_dek", head_w, 34, markup=True, min_size=6.5) if parts else (None, 0)
    total = hh + (3 if hp and sp else 0) + sh
    top = 689.5 - total / 2 if total else 684.0
    pg.label(39.6, top + 9.0, "OPINION")
    if not caption and not parts:
        pg.write("No named estimates were published today.", "note", head_x, top, head_w)
    if hp:
        pg.put(hp, hh, head_x, top)
    if sp:
        pg.put(sp, sh, head_x, top + hh + 3)
    pg.write(RELIABILITY, "op_dek", 443.9, 652.5, 57.0, max_h=76, min_size=5.2)
    url = next((s.get("url") for s in statements if s.get("url")), "")
    if pg.qr(url, 507.7, 680.2, 22.5):
        pg.text(534.9, 693.0, "SCAN FOR MORE", "Mono", 5.2)


# ---------------------------------------------------------------- page two --
def page_two(pg, ed):
    mast_date, long_date, short_date = _dates((ed.get("edition") or {}).get("date"))
    pg.bar(LEFT, 28.5, WIDTH, 0.7)
    pg.text(42.6, 48.0, "The AI Horizons Times", "Serif-Bold", 14.2)
    pg.text(347.3, 46.5, "Continued", "Serif-Italic", 8.2)
    pg.text(569.0, 46.5, "Page Two", "Serif-Italic", 8.2, align="right")
    pg.bar(LEFT, 57.0, WIDTH, 1.5)
    pg.bar(LEFT, 59.2, WIDTH, 1.5, ACCENT)

    wq = ed.get("workiq") or {}
    your_day(pg, wq, long_date)
    be_ready(pg, wq)
    pg.bar(LEFT, 281.2, WIDTH, 0.7)

    bs = ed.get("bright_side") or {}
    items = (bs.get("items") or [])[:3] if _ok(bs) else []
    slots = [(39.6, 39.7, 0.0), (316.5, 316.5, 0.0), (39.6, 39.7, 234.8), (316.5, 316.5, 234.8)]
    for i in range(3):
        tx, qx, dy = slots[i]
        bright_card(pg, items[i] if i < len(items) else None, tx, qx, dy, short_date)
    tx, qx, dy = slots[3]
    desk_card(pg, wq, tx, dy, short_date)
    pg.bar(305.2, 291.0, 0.7, 453.7)
    pg.bar(LEFT, 517.5, WIDTH, 0.7)
    pg.bar(LEFT, 744.7, WIDTH, 0.7)
    pg.footer("PAGE 02")


def your_day(pg, wq, long_date):
    pg.tag(LEFT, 69.7, "YOUR DAY")
    col_w = 262.0
    if not _ok(wq):
        pg.write(NOTICE, "note", 39.6, 88.0, col_w)
        return
    burning = wq.get("burning") or []
    b, i, w = len(burning), len(wq.get("important") or []), len(wq.get("waiting") or [])
    headline = f"{b} burning, {i} important, {w} waiting"
    top = 86.5
    top += pg.write(headline, "feat_head", 39.6, top, col_w, max_h=62, min_size=13)
    pg.text(39.6, top + 8.0, f"{BYLINE} · FROM WORK IQ · {long_date}", "Mono", 6.7, MUTED)
    top += 14.5
    if burning:
        rows = []
        for item in burning:
            due = f" · due {_esc(item['due'])}" if item.get("due") else ""
            rows.append(f"• <b>{_esc(item.get('title'))}</b>{due}. {_esc(item.get('why'))}")
        pg.write_rows(rows, "feat_body", 39.6, top, col_w, max_h=max(228.0 - top, 14), min_size=7.5)
        if pg.qr(burning[0].get("source_url"), 39.7, 234.7, 37.5):
            pg.text(84.6, 252.0, "SCAN FOR", "Mono", 6.7)
            pg.text(84.6, 259.5, "TOP PRIORITY →", "Mono", 6.7)
    else:
        pg.write("Nothing is burning today.", "feat_body", 39.6, top, col_w)


def be_ready(pg, wq):
    x, top, w, h = 312.7, 69.7, 259.5, 202.5
    pg.frame(x, top, w, h)
    ix, iw = x + 10, w - 20
    pg.label(ix, 82.5, "BE READY FOR", 6.7)
    y = 86.5
    y += pg.write("Questions you may be asked this week", "panel_head", ix, y, iw) + 5
    if not _ok(wq):
        pg.write(NOTICE, "note", ix, y, iw)
        return
    items = wq.get("be_ready_for") or []
    if not items:
        pg.write("No questions are expected this week.", "note", ix, y, iw)
        return
    limit = top + h - 8
    qr_size = 22.0
    per_item = (limit - y) / len(items[:3])
    for item in items[:3]:
        has_qr = bool(item.get("source_url"))
        tw = iw - (qr_size + 6 if has_qr else 0)
        text = (f"<b>{_esc(item.get('topic'))}</b><br/><i>Q: {_esc(item.get('likely_question'))}</i>"
                f"<br/>{_esc(item.get('two_line_answer'))}")
        p, ph = pg.para(text, "panel_body", tw, per_item - 6, markup=True, min_size=6)
        pg.bar(ix, y, iw, 0.5)
        pg.put(p, ph, ix, y + 3)
        if has_qr:
            pg.qr(item["source_url"], ix + iw - qr_size, y + 4, qr_size)
        y += max(ph, qr_size if has_qr else 0) + 7


def bright_card(pg, item, tx, qx, dy, short_date):
    tw = 255.0
    if not item:
        pg.label(tx, 296.2 + dy, "THE BRIGHT SIDE")
        pg.write(NOTICE, "note", tx, 302.0 + dy, tw)
        return
    domain = str(item.get("domain", "")).upper()
    pg.label(tx, 296.2 + dy, "THE BRIGHT SIDE" + (f" · {domain}" if domain else ""))
    top = 301.8 + dy
    top += pg.write(item.get("headline", ""), "card2_head", tx, top, tw, max_h=40, min_size=9)
    pg.text(tx, top + 6.5, f"{BYLINE} · {short_date}", "Mono", 5.6, MUTED)
    top += 11.5
    bottom = 478.0 + dy
    top += pg.write(item.get("dek", ""), "card2_dek", tx, top, tw, max_h=48, min_size=7) + 4
    if item.get("evidence"):
        top += pg.write(f"<b>Evidence:</b> {_esc(item['evidence'])}", "card2_dek", tx, top, tw,
                        max_h=max(bottom - top - 26, 12), markup=True, min_size=7) + 4
    if item.get("caveat"):
        pg.write(f"Caveat: {item['caveat']}", "note", tx, top, tw, max_h=max(bottom - top, 10), min_size=6.5)
    if pg.qr(item.get("url"), qx, 484.5 + dy, 24.0):
        pg.text(qx + 28.4, 498.0 + dy, "SCAN FOR MORE", "Mono", 5.2)


def desk_card(pg, wq, tx, dy, short_date):
    tw = 255.0
    pg.label(tx, 296.2 + dy, "ON YOUR DESK · FROM WORK IQ")
    if not _ok(wq):
        pg.write(NOTICE, "note", tx, 302.0 + dy, tw)
        return
    top = 301.8 + dy
    top += pg.write("Important this week, and waiting on others", "card2_head", tx, top, tw, max_h=40)
    pg.text(tx, top + 6.5, f"{BYLINE} · {short_date}", "Mono", 5.6, MUTED)
    top += 13.0
    rows = []
    for item in wq.get("important") or []:
        due = f" · due {_esc(item['due'])}" if item.get("due") else ""
        rows.append(f"• <b>{_esc(item.get('title'))}</b>{due}. {_esc(item.get('why'))}")
    for item in wq.get("waiting") or []:
        since = f" since {_esc(item['since'])}" if item.get("since") else ""
        rows.append(f"• <b>{_esc(item.get('title'))}</b>. Waiting on {_esc(item.get('waiting_on'))}{since}.")
    can_wait = int(wq.get("can_wait_count") or 0)
    if can_wait:
        rows.append(f"<i>A further {can_wait} items can wait.</i>")
    if not rows:
        rows.append("<i>Nothing is waiting on your desk.</i>")
    pg.write_rows(rows, "card2_dek", tx, top, tw, max_h=740.0 - top, min_size=7)



# ---------------------------------------------------------------- validation --
def _has_digit(value):
    return any(ch.isdigit() for ch in str(value or ""))


def validate(edition):
    """Check the edition and remove items that break the contract.

    Structural problems raise ValueError, so nothing is printed. Content problems
    remove only the affected items and are reported as NOTE lines.
    """
    notes = []
    if not isinstance(edition, dict):
        raise ValueError("the edition must be a JSON object")
    meta = edition.get("edition")
    if not isinstance(meta, dict) or not meta.get("date"):
        raise ValueError("edition.date is missing")
    try:
        datetime.strptime(str(meta["date"]), "%Y-%m-%d")
    except ValueError:
        raise ValueError("edition.date must use the format YYYY-MM-DD")

    for key in ("workiq", "news", "bright_side", "doom"):
        if not isinstance(edition.get(key), dict):
            notes.append(f"section {key} is missing and prints as unavailable")
            edition[key] = {"status": "unavailable"}

    news = edition["news"]
    if _ok(news):
        lead = news.get("lead")
        if not isinstance(lead, dict) or not lead.get("headline"):
            notes.append("the lead story has no headline and prints as a notice")
            news["lead"] = None
        kept, seen = [], set()
        for story in news.get("stories") or []:
            section = str((story or {}).get("section", "")).upper()
            if section not in SECTIONS or not story.get("headline"):
                notes.append(f"a story without a valid section or headline was left out ({section or 'no section'})")
                continue
            if section in seen:
                notes.append(f"a second {section} story was left out")
                continue
            seen.add(section)
            kept.append(story)
        news["stories"] = kept

    bs = edition["bright_side"]
    if _ok(bs):
        kept, domains = [], set()
        for item in bs.get("items") or []:
            domain = str((item or {}).get("domain", "")).strip().lower()
            if not item.get("headline") or domain not in BRIGHT_DOMAINS:
                notes.append(f"a Bright Side item without a headline or a valid domain was left out ({domain or 'no domain'})")
                continue
            if domain in domains:
                notes.append(f"a second Bright Side item in the domain {domain} was left out")
                continue
            domains.add(domain)
            kept.append(item)
        bs["items"] = kept[:3]

    doom = edition["doom"]
    kept = []
    for st in doom.get("statements") or []:
        person = str((st or {}).get("person", "")).strip()
        if person.lower() in GENERIC_SPEAKERS or not _has_digit(st.get("pct_text")):
            notes.append(f"a doom statement without a named speaker or a figure was left out ({person or 'no name'})")
            continue
        kept.append(st)
    doom["statements"] = kept
    doom["_valid"] = (_ok(doom) and doom.get("median_pct") is not None
                      and int(doom.get("n") or 0) >= MIN_STATEMENTS and len(kept) >= MIN_STATEMENTS)
    if _ok(doom) and not doom["_valid"]:
        notes.append("the doom reading was not printed because fewer than three named statements with figures remain")
    return edition, notes

# ---------------------------------------------------------------- main --
def build_pdf(edition, output, thresholds=(5.0, 20.0), mono=False, edition_number=None):
    from reportlab.pdfgen import canvas

    register_fonts()
    if edition_number is not None:
        edition.setdefault("edition", {})
        if not edition["edition"].get("edition_number"):
            edition["edition"]["edition_number"] = edition_number
    c = canvas.Canvas(output, pagesize=(PAGE_W, PAGE_H))
    date = (edition.get("edition") or {}).get("date", "")
    c.setTitle(f"The AI Horizons Times {date}".strip())
    c.setAuthor("The Editor")
    pg = Page(c, thresholds, "mono" if mono else "color")
    page_one(pg, edition)
    c.showPage()
    page_two(pg, edition)
    c.showPage()
    c.save()


def main(argv):
    parser = argparse.ArgumentParser(description="Render The AI Horizons Times edition as a PDF.")
    src = parser.add_mutually_exclusive_group(required=True)
    src.add_argument("--edition-json", help="Edition data as a JSON string.")
    src.add_argument("--edition-file", help="Path to a JSON file with the edition data.")
    parser.add_argument("--output", default="ai_horizons_times.pdf",
                        help="Output PDF path (default: ai_horizons_times.pdf).")
    parser.add_argument("--edition-number", type=int, default=None,
                        help="Edition number to print when the JSON has none.")
    parser.add_argument("--thresholds", type=float, nargs=2, default=(5.0, 20.0),
                        metavar=("GREEN_MAX", "YELLOW_MAX"),
                        help="Upper limits of the green and yellow gauge bands in percent.")
    parser.add_argument("--mono", action="store_true", help="Draw the gauge in greys.")
    args = parser.parse_args(argv[1:])

    low, high = args.thresholds
    if not 0 < low < high < 100:
        print("Error: the thresholds must satisfy 0 < GREEN_MAX < YELLOW_MAX < 100.")
        return 1
    try:
        if args.edition_json:
            edition = json.loads(args.edition_json)
        else:
            with open(args.edition_file, "r", encoding="utf-8") as fh:
                edition = json.load(fh)
    except (ValueError, OSError) as exc:
        print(f"Error: could not read edition JSON ({exc}).")
        return 1
    try:
        edition, notes = validate(edition)
    except ValueError as exc:
        print(f"Error: the edition JSON is invalid ({exc}).")
        return 1
    try:
        build_pdf(edition, args.output, (low, high), args.mono, args.edition_number)
    except ImportError:
        print("Error: reportlab is required to render the edition PDF.")
        return 1
    except OSError as exc:
        print(f"Error: could not load the bundled fonts or write the PDF ({exc}).")
        return 1
    for note in notes:
        print(f"NOTE: {note}")
    print(f"WROTE {args.output}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
